function multiply(x, y)
{
  return x + y;
}

console.log(multiply(5, 6));