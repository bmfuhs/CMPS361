# Web Development With Node And Express

This is the companion repository to [Web Development With Node and Express, 1st Edition](http://shop.oreilly.com/product/0636920032977.do).  With this repository, you can follow along with any of the code samples in the book, as well as see additional material that wasn't appropriate for the book format.

## The Process

I've now finished the book, and it's time to build out the repository.  I will be going through the book as the reader would, and checking in my code.  I will be adding tags for every chapter and then select sections in the book.  Once I'm done, I'll update this readme file with more information.

