
var express = require('express');
var path = require('path');
var app = express('path');
var exphbs = require('express-handlebars');
app.engine('handlebars', exphbs({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');
app.set('port', process.env.PORT || 3000);
var options = { dotfiles: 'ignore', etag: false,
extensions: ['htm', 'html'],
index: "hello.html"
};
app.use(express.static(path.join(_dirname, 'public') , options ));

var sayings = [
  "Life's a lottery, and man should make up his mind to the blanks",
  "Luck is great, but most of life is hard work",
  "You lucky dog",
  "We should probably leave",
  "Better luck next time, try again",
];

app.get('/', function(req,res) {
  res.render('home');
});
app.get('/about', function(req,res){
  var randomSaying =
    sayings[Math.floor(Math.randon() * sayings.length)];
  res.render('about', { saying: randomSaying });
});

app.get('/hello', function(req,res){
       res.render('hello');
});

app.get('/home', function(req, res){
      res.render('hello');
});

app.get('/home', function(req, res){
       res.render('home');
});

//404
app.use(function(req, res, next){
  res.status(404);
  res.render('404');
});

//500 Error
app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500);
  res.render('500');
});

app.listen(app.get('port'), function(){
  console.log(' Express started on http://localhost:' +
  app.get('port') + '; press Ctrl-C to terminate.' );
});
