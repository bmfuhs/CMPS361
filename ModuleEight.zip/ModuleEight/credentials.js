
module.exports = {
  cookieSecret: 'One-for-the-thumb',
  gmail: {
           user: 'your user',
           password:  'your password',
         },
 mongo: {
       development: {
            connectionString: 'mongodb://',
         },
             production: {
            connectionString: 'mongodb://'
        }
      }
};
